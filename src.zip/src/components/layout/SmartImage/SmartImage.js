import React, { useState } from 'react';
import Skeleton from '../Skeleton/Skeleton';
import './SmartImage.css';

const SmartImage = ({ src, alt = "Sneaker Sberdila", className = '', fallbackSrc = 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1000&auto=format&fit=crop', ...props }) => {
    const [isLoaded, setIsLoaded] = useState(false);
    const [imgSrc, setImgSrc] = useState(src);
    const [hasError, setHasError] = useState(false);

    const handleError = () => {
        if (!hasError) {
            setImgSrc(fallbackSrc);
            setHasError(true);
        }
    };

    return (
        <div
            className={`smart-image-container ${isLoaded ? 'loaded' : 'loading'} ${className}`}
            role="img"
            aria-label={alt}
        >
            <img
                src={imgSrc || fallbackSrc}
                alt={alt}
                onLoad={() => setIsLoaded(true)}
                onError={handleError}
                loading="lazy"
                decoding="async"
                className={`smart-image-img ${isLoaded ? 'visible' : 'hidden'}`}
                {...props}
            />
            {!isLoaded && (
                <div className="smart-image-placeholder" aria-hidden="true">
                    <Skeleton height="100%" borderRadius="inherit" />
                </div>
            )}
        </div>
    );
};

export default SmartImage;
